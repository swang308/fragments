// src/model/fragment.js

// Use crypto.randomUUID() to create unique IDs, see:
// https://nodejs.org/api/crypto.html#cryptorandomuuidoptions
const { randomUUID } = require('crypto');
// Use https://www.npmjs.com/package/content-type to create/parse Content-Type headers
const contentType = require('content-type');

const logger = require('../logger');

// Functions for working with fragment metadata/data using our DB
const {
  readFragment,
  writeFragment,
  readFragmentData,
  writeFragmentData,
  listFragments,
  deleteFragment,
} = require('./data');

class Fragment {
  constructor({ id, ownerId, created, updated, type, size = 0 }) {
    if (!ownerId || !type) {
      throw new Error('ownerId and type are required')
    }

    if (typeof size !== 'number') {
      throw new Error('Size must be a number');
    }

    if (size < 0) {
      throw new Error('Size cannot be negative');
    }

    if (!type.length) {
      throw new Error('Type cannot be empty');
    } else {
      if (!Fragment.isSupportedType(type)) {
        throw new Error('Invalid fragment type');
      }
    }

    this.id = id || randomUUID();
    this.ownerId = ownerId;
    this.created = created || new Date().toISOString();
    this.updated = updated || new Date().toISOString();
    this.type = type;
    this.size = size;
  }

  /**
   * Get all fragments (id or full) for the given user
   * @param {string} ownerId user's hashed email
   * @param {boolean} expand whether to expand ids to full fragments
   * @returns Promise<Array<Fragment>>
   */
  static async byUser(ownerId, expand = false) {
    try {
      const fragments = await listFragments(ownerId, expand);
      if (expand) {
        return fragments.map((fragment) => new Fragment(fragment));
      }
      return fragments;
    } catch (error) {
      return [];
    }
  }

  /**
   * Gets a fragment for the user by the given id.
   * @param {string} ownerId user's hashed email
   * @param {string} id fragment's id
   * @returns Promise<Fragment>
   */
  static async byId(ownerId, id) {
    try {
      const result = await readFragment(ownerId, id);
      if (!result) {
        throw new Error('Fragment with id not found');
      }
      return result;
    } catch (error) {
      throw new Error(error);
    }
  }

  /**
   * Delete the user's fragment data and metadata for the given id
   * @param {string} ownerId user's hashed email
   * @param {string} id fragment's id
   * @returns Promise<void>
   */
  static async delete(ownerId, id) {
    logger.info('Deleted fragment data and metadata');
    await deleteFragment(ownerId, id);
  }

  /**
   * Saves the current fragment to the database
   * @returns Promise<void>
   */
  async save() {
    this.updated = new Date().toISOString();
    try {
      await writeFragment(this);
      logger.info('Fragment saved successfully');
    } catch (error) {
      logger.error('Error saving fragment');
      throw new Error('Error saving fragment');
    }
  }

  /**
   * Gets the fragment's data from the database
   * @returns Promise<Buffer>
   */
  getData() {
    return readFragmentData(this.ownerId, this.id);
  }

  /**
   * Set's the fragment's data in the database
   * @param {Buffer} data
   * @returns Promise<void>
   */
  async setData(data) {
    try {
      if (!(data instanceof Buffer)) {
        logger.Error('Data must be a Buffer')
        throw new Error('Data must be a Buffer');
      }
      this.updated = new Date().toISOString();
      this.size = Buffer.byteLength(data);
      return await writeFragmentData(this.ownerId, this.id, data);
    } catch (error) {
      logger.error('Error setting the fragment data');
      throw new Error('Error setting the fragment data');
    }
  }

  /**
   * Returns the mime type (e.g., without encoding) for the fragment's type:
   * "text/html; charset=utf-8" -> "text/html"
   * @returns {string} fragment's mime type (without encoding)
   */
  get mimeType() {
    const { type } = contentType.parse(this.type);
    return type;
  }

  /**
   * Returns true if this fragment is a text/* mime type
   * @returns {boolean} true if fragment's type is text/*
   */
  get isText() {
    return this.type.startsWith('text/');
  }

  /**
   * Returns the formats into which this fragment type can be converted
   * @returns {Array<string>} list of supported mime types
   */
  get formats() {
    // let formats = [];

    // if (this.type.startsWith('text/plain')) {
    //   formats = ['text/plain'];
    // }
    // return formats;
    let result = [];
    if (
      this.type.includes('image/png') ||
      this.type.includes('image/jpeg') ||
      this.type.includes('image/gif') ||
      this.type.includes('image/webp')
    ) {
      result = ['image/png', 'image/jpeg', 'image/gif', 'image/webp'];
    } else if (this.type.includes('text/plain')) {
      result = ['text/plain'];
    } else if (this.type.includes('text/markdown')) {
      result = ['text/plain', 'text/html', 'text/markdown'];
    } else if (this.type.includes('text/html')) {
      result = ['text/plain', 'text/html'];
    } else if (this.type.includes('application/json')) {
      result = ['application/json', 'text/plain'];
    } else if (this.type.includes('text/csv')) {
      result = ['text/csv', 'text/plain', 'text/json'];
    }
    return result;
  }

  /**
   * Returns true if we know how to work with this content type
   * @param {string} value a Content-Type value (e.g., 'text/plain' or 'text/plain: charset=utf-8')
   * @returns {boolean} true if we support this Content-Type (i.e., type/subtype)
   */
  static isSupportedType(value) {
    let validType = [
      'text/plain',
      'text/plain; charset=utf-8',
      'text/markdown',
      'text/html',
      'text/csv',
      'application/json',
      'image/png',
      'image/jpeg',
      'image/webp',
      'image/avif',
      'image/gif',
    ];
    return validType.includes(value);
  }
}

module.exports.Fragment = Fragment;
